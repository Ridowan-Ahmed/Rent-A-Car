@extends('layouts.main')
@section('content')
    <div class="text-center mt-5">
        <h1>You Need to Pay First <i class="fa fa-smile-o"></i></h1>
    </div>
@stop

@section('script')
@stop