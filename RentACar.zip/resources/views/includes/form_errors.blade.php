@if(count($errors) > 0)
    <br>
    <div class="alert alert-danger">
        <ol>
            @foreach($errors->all()  as $error)
                <li>{{$error}}</li>
            @endforeach
        </ol>
    </div>
@endif