<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">Company</li>
        </ol>
    </nav>
    <div id="userCompany dark-overlay">
        <?php if(count($companies)): ?>
        <table class="table table-responsive-sm">
            <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Car</th>
                <th scope="col">Address</th>
                <th scope="col">Phone No.</th>
                <th scope="col">Remarks</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($company->id); ?></th>
                    <td><a href="<?php echo e(route('company.show',$company->slug)); ?>"><?php echo e($company->name); ?></a></td>
                    <td><?php echo e(count($company->car)); ?></td>
                    <td><?php echo e($company->address); ?></td>
                    <td><?php echo e($company->phone_num); ?></td>
                    <td><?php echo e($company->remarks); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
            <p>No Company added yet</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>