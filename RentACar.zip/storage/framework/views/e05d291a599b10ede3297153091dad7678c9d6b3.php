<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">Owner</li>
        </ol>
    </nav>
    <div id="userCompany dark-overlay">
        <?php if(count($owners)): ?>
        <table class="table table-responsive-sm">
            <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Car</th>
                <th scope="col">Address</th>
                <th scope="col">Phone No.</th>
                <th scope="col">Remarks</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($owner->id); ?></th>
                    <td><a href="<?php echo e(route('owner.show',$owner->slug)); ?>"><?php echo e($owner->name); ?></a></td>
                    <td><?php echo e(count($owner->car)); ?></td>
                    <td><?php echo e($owner->address); ?></td>
                    <td><?php echo e($owner->phone_num); ?></td>
                    <td><?php echo e($owner->remarks); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <p>No Owner added yet</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>