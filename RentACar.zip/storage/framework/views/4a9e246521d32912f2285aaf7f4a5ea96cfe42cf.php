<?php $__env->startSection('content'); ?>
<div id="userProfile">
    <div class="row mt-5">

        <div class="col-md-5">
            <?php echo Form::model($user, ['method'=>'PATCH', 'action'=>['UserController@update', $user->id], 'files'=>true]); ?>

            <img src="<?php echo e($user->photoSrc()); ?> " alt="Image" class="img-fluid img-thumbnail rounded-circle mb-4">
            <div class="from-group mt-4">
                <?php echo Form::label('photo_id', 'Upload Image'); ?>

                <?php echo Form::file('photo_id', null, ['class'=>'form-control']); ?><br>
            </div>
        </div>
        <div class="col-md-7 mt-5">
            <div class="form-group">
                <div class="input-group mb-2">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fa fa-user"></i></div>
                    </div>
                    <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

                </div>
            </div>
            <br>
            <div class="form-group">
                <div class="input-group mb-2">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fa fa-envelope"></i></div>
                    </div>
                    <?php echo Form::email('email', null, ['class'=>'form-control']); ?>

                </div>
            </div>
            <br>
            <div class="form-group">
                <div class="input-group mb-2">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fa fa-lock"></i></div>
                    </div>
                    <?php echo Form::password('password', ['class'=>'form-control']); ?>

                </div>
            </div>
            <hr>
            <div class="from-group ml-5 float-right">
                <?php echo Form::submit('Update Info', ['class'=>'btn btn-success float-left']); ?>

            </div>
            <?php echo Form::close(); ?>


            <?php echo Form::open(['id'=>'deleteForm','method'=>'DELETE','action'=>['UserController@destroy', $user->id]]); ?>

            <div class="from-group mr-5">
                <?php echo Form::submit('Delete Account', ['id'=>'deleteButton','class'=>'btn btn-danger float-right']); ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>