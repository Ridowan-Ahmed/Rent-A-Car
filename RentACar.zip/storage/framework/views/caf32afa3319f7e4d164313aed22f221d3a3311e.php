<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">Driver</li>
        </ol>
    </nav>
    <div id="allDriver">
        <div class="row">
            <?php if(count($drivers) > 0): ?>
                <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-12 col-md-5 card m-2">
                    <div class="media wow zoomInDown">
                        <img class="d-flex mr-3 align-self-start img-thumbnail hidden-md-down" src="<?php echo e($driver->photo->photo_path); ?>" style='height: 35%; width: 35%; object-fit: contain' alt="User Photo">
                        <div class="media-body">
                            <h5 class="mt-2">
                                <a href="<?php echo e(route('driver.show', $driver->slug)); ?>"><?php echo e($driver->name); ?></a> <span class="badge badge-primary badge-pill"><?php echo e($driver->education); ?></span>
                            </h5>
                            <?php
                                $dt = new \Carbon\Carbon($driver->join_date)
                            ?>
                            <p>Joined <span class="font-weight-bold"><?php echo e($dt->diffFOrHumans()); ?></span></p>
                            <p>Salary <span class="font-weight-bold"><?php echo e($driver->salary); ?> &#x9f3;</span></p>
                            <p>Lives at <?php echo e($driver->address); ?></p>
                            <p><?php echo e($driver->remarks); ?></p>
                            <div class="bottom-align-text mb-1 mr-1 float-right">
                                <?php echo Form::open(['method'=>'DELETE', 'action'=>['DriverController@destroy', $driver->slug]]); ?>

                                <a href="<?php echo e(route('driver.edit', $driver->slug)); ?>" class="card-link btn btn-sm btn-outline-primary">
                                    <i class="fa fa-pencil"></i> Edit
                                </a>
                                <?php echo Form::button('<i class="fa fa-trash"></i> Delete', ['type' => 'submit', 'class' => 'card-link btn btn-sm btn-outline-danger'] ); ?>


                                <?php echo Form::close(); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h3>No Drivers</h3>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>