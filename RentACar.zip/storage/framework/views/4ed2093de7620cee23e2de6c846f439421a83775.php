<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/owner">Owner</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('owner.show', $car->owner->slug)); ?>"><?php echo e($car->owner->name); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Daily Log</li>
                </ol>
            </nav>
        </ol>
    </nav>
    <div id="carLog" class="">
        <h1 class="display-5" id="logIndex">
            <i class="fa fa-taxi"></i> <?php echo e($car->registration_num); ?> <span class="badge badge-primary badge-pill"><?php echo e($car->car_brand); ?></span>
        </h1>
        <a href="<?php echo e(route('car.report', $car->registration_num)); ?>" class="btn btn-outline-primary">Full Report</a>

        <div id="carInfo">
            <div class="row">
                <div class="col-sm-6">
                    <ul class="list-group"> Expiry
                        <li class="list-group-item">Tax Token <?php echo e($car->tax_token_expiry_date->diffForHumans()); ?></li>
                        <li class="list-group-item">Fitness <?php echo e($car->fitness_expiry_date->diffForHumans()); ?></li>
                        <li class="list-group-item">Insurance <?php echo e($car->insurance_expiry_date->diffForHumans()); ?></li>
                        <li class="list-group-item">Road Permit <?php echo e($car->road_permit_expiry_date->diffForHumans()); ?></li>
                    </ul>
                </div>
                <div class="col-sm-6">
                    <ul class="list-group">
                        Driver
                        <li class="list-group-item">Name <?php echo e($car->driver_name); ?></li>
                        <li class="list-group-item">Lives in <?php echo e($car->driver_address); ?></li>
                        <li class="list-group-item">Phone Number: <?php echo e($car->driver_phone_num); ?></li>
                        <li class="list-group-item">National ID: <?php echo e($car->driver_nid); ?></li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="logControl" class="text-center my-2">
            <a href="<?php echo e(route('logbook.showPastTwo', $car->registration_num)); ?>" class="btn btn-outline-primary">Past Two Month</a>
            <a href="<?php echo e(route('logbook.showPast', $car->registration_num)); ?>" class="btn btn-outline-success">Past Month</a>
            <a href="<?php echo e(route('logbook.show', $car->registration_num)); ?>" class="btn btn-outline-secondary">This Month</a>
        </div>
        <?php if(count($car->logbooks) > 0): ?>
        <table class="table table-danger table-responsive-sm table-bordered table-hover table-stripped">
            <thead class="">
            <tr>
                <th>Date</th>
                <th>Total Run</th>
                <th>Starting Time</th>
                <th>Ending Time</th>
                <th>Working</th>
                <th>Duty</th>
                <th>Overtime</th>
                <th>Payment Reason</th>
                <th>Payment Type</th>
                <th>Amount</th>
            </tr>
            </thead>
            <tbody class="wow fadeInDownBig">
                <?php $__currentLoopData = $logbooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php
                            $date = new \Carbon\Carbon($logbook->log_date);
                            $start = new \Carbon\Carbon($logbook->starting_time);
                            $end = new \Carbon\Carbon($logbook->ending_time);
                            $working_time = $end->diffInHours($start);
                        ?>
                        <td><?php echo e($date->toFormattedDateString()); ?></td>
                        <td><?php echo e($logbook->ending_km-$logbook->starting_km); ?> KM</td>
                        <td><?php echo e($start->format('h:i A')); ?></td>
                        <td><?php echo e($end->format('h:i A')); ?></td>
                        <td><?php echo e($working_time); ?> h</td>
                        <td><?php echo e($logbook->duty_time); ?> h</td>
                        <td>
                            <?php if($working_time === $logbook->duty_time): ?>
                                <h5><span class="badge badge-primary badge-pill"><i class="fa fa-check-circle-o"></i> OK</span></h5>
                            <?php elseif($working_time > $logbook->duty_time): ?>
                                <h5><span class="badge badge-danger badge-pill"><i class="fa fa-check-circle-o"></i> <?php echo e($working_time - $logbook->duty_time); ?> h</span></h5>
                            <?php else: ?>
                                <?php echo e($logbook->duty_time - $working_time); ?> h less
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($logbook->payment_reason); ?></td>
                        <td><?php echo e($logbook->payment_type); ?></td>
                        <td><?php echo e($logbook->payment_amount); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>No Entry yet</p>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>