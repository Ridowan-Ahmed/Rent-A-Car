<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/driver">Driver</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($driver->name); ?></li>
        </ol>
    </nav>
    <div id="allDriver">
        <div class="row">
            <div class="col">
                <table class="table table-bordered table-hover table-stripped">
                    <?php
                        $total = 0;
                    ?>
                    <thead class="thead-dark">
                    <tr>
                        <th>Date</th>
                        <th>Car</th>
                        <th>Total Drive</th>
                        <th>Overtime</th>
                        <th>Overtime Pay</th>
                        <th>Payment Reason</th>
                        <th>Payment Type</th>
                        <th>Amount</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $driver_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php
                            $date =new \Carbon\Carbon($log->date);
                            $start =new \Carbon\Carbon($log->starting_time);
                            $end =new \Carbon\Carbon($log->ending_time);
                            $working_time = $end->diffInHours($start);
                            $overtime_hour = $working_time - $log->duty_time;
                            $total = $total + $log->payment_amount;
                            ?>
                            <td><?php echo e($date->toFormattedDateString()); ?></td>
                            <td><?php echo e(\App\Car::findOrFail($log->car_id)->car_model); ?></td>
                            <td><?php echo e($log->ending_km-$log->starting_km); ?> KM</td>
                            <td>
                                <?php if($working_time === $log->duty_time): ?>
                                    <h5><span class="badge badge-primary badge-pill"><i class="fa fa-check-circle-o"></i> OK</span></h5>
                                <?php elseif($working_time > $log->duty_time): ?>
                                    <?php echo e($working_time - $log->duty_time); ?> h more
                                <?php else: ?>
                                    <?php echo e($log->duty_time - $working_time); ?> h less
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($working_time > $log->duty_time): ?>
                                <?php echo e($log->overtime_money * $overtime_hour); ?>

                                <?php else: ?>
                                    0
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($log->payment_reason); ?></td>
                            <td><?php echo e($log->payment_type); ?></td>
                            <td><?php echo e($log->payment_amount); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-secondary text-white">
                            <td colspan="6" class="text-right">Salary: <?php echo e($driver->salary); ?></td>
                            <td>Total: <?php echo e($total); ?></td>
                        </tr>
                        <tr class="bg-secondary text-white">
                            <td colspan="6" class="text-right">Owe: <?php echo e($driver->salary - $total); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>