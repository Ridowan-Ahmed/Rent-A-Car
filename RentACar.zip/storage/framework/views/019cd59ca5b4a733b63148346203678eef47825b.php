<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/company">Company</a></li>
        <li class="breadcrumb-item active" aria-current="page">Create</li>
    </ol>
</nav>
<h3 class="h3"><i class="fa fa-audio-description"></i> Company</h3>
    
    <div class="container img-thumbnail">
        <?php echo Form::open(['method'=>'POST', 'action'=>'CompanyController@store', 'files'=>true]); ?>

        <div class="from-group row mb-3">
            <?php echo Form::label('name', 'Name', ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::text('name', null, ['placeholder' => 'Company Name...','class'=>'form-control']); ?>

                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
            </div>
        </div>
        <div class="from-group row mb-3">
            <?php echo Form::label('address', 'Address', ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::text('address', null, ['placeholder' => 'Current Address...','class'=>'form-control']); ?>

                <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
            </div>
        </div>
        <div class="from-group row mb-3">
            <?php echo Form::label('phone_num', 'Phone Number', ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::text('phone_num', null, ['placeholder' => '01XXXXXXXXX','class'=>'form-control']); ?>

                <span class="text-danger"><?php echo e($errors->first('phone_num')); ?></span>
            </div>
        </div>
        <div class="from-group row mb-3">
            <?php echo Form::label('remarks', 'Remarks', ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::text('remarks', null, ['placeholder' => 'A short note about the company','class'=>'form-control']); ?>

            </div>
        </div>
        <div class="from-group row mb-3">
            <?php echo Form::label('photo_id', "Company's Logo", ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::file('photo_id', null, ['class'=>'form-control']); ?>

            </div>
        </div>
        <div class="from-group">
            <?php echo Form::submit('Submit', ['class'=>'btn btn-primary float-right mr-5']); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>