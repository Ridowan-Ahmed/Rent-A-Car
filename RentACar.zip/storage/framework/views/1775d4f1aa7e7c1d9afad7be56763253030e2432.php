<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/driver">Driver</a></li>
            <li class="breadcrumb-item active" aria-current="page">Edit</li>
        </ol>
    </nav>
    <h3 class="display-4">
        <i class="fa fa-user-times"></i> Add Driver
    </h3>
    <?php echo $__env->make('includes.form_errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container img-thumbnail">
    <?php echo Form::model($driver, ['method'=>'PATCH', 'action'=>['DriverController@update', $driver->slug], 'files'=>true]); ?>

        <div class="from-group row mb-2">
            <?php echo Form::label('name', 'Name', ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::text('name', null, ['placeholder' => "Driver's name",'class'=>'form-control']); ?>

            </div>
        </div>
        <div class="form-group row mb-2">
            <?php echo Form::Label('join_date', 'Join Date:', ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::date('join_date', null,['class' => 'form-control']); ?>

            </div>
        </div>
        <div class="form-group row mb-2">
            <?php echo Form::Label('salary', 'Salary:', ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::number('salary', null,['placeholder' => 'Monthly salary', 'class' => 'form-control']); ?>

            </div>
        </div>
        <div class="from-group row mb-2">
            <?php echo Form::label('education', 'Education', ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::select('education',
                    [null => 'None',
                     'SSC' => 'SSC',
                     'HSC' => 'HSC',
                     'Degree' => 'Degree',
                     'Other' => 'Other'],
                    null, ['class'=>'form-control']); ?>

            </div>
        </div>
        <div class="form-group row mb-2">
            <?php echo Form::Label('address', 'Address:', ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::text('address', null, ['class' => 'form-control']); ?>

            </div>
        </div>
        <div class="from-group row mb-2">
            <?php echo Form::label('phone_num', 'Phone Number', ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::text('phone_num', null, ['placeholder' => '01XXXXXXXXX','class'=>'form-control']); ?>

            </div>
        </div>
        <div class="from-group row mb-2">
            <?php echo Form::label('remarks', 'Remarks', ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::text('remarks', null, ['placeholder' => 'A short note.....','class'=>'form-control']); ?>

            </div>
        </div>
        <div class="from-group row mb-2">
            <?php echo Form::label('photo_id', 'Image', ['class'=>'col-sm-2 col-form-label font-weight-bold']); ?>

            <div class="col-sm-10">
                <?php echo Form::file('photo_id', null, ['class'=>'form-control']); ?>

            </div>
        </div>
        <div class="from-group">
            <?php echo Form::submit('Submit', ['class'=>'btn btn-primary float-right mr-5']); ?>

        </div>
    <?php echo Form::close(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>