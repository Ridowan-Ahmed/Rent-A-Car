<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item active" aria-current="page">Car</li>
    </ol>
</nav>
<div id="userCar">
        <div class="row">
            <?php if(count($cars) > 0): ?>
                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    <div class="card border-success wow zoomInDown">
                        <div class="card-header bg-transparent border-success">
                            <h5 class="card-title">
                                <?php echo e($car->registration_num); ?> <span class="badge badge-success badge-pill"><?php echo e($car->car_brand); ?></span>
                            </h5>
                            <p class="card-text">
                                <small>Owner</small> <?php echo e(\App\Owner::findOrFail($car->owner_id)->name); ?>

                                <a href="<?php echo e(route('logbook.show', $car->registration_num)); ?>" class="btn btn-sm btn-outline-success float-right">
                                    <i class="fa fa-book"></i> Log
                                </a>
                            </p>
                        </div>
                        <div class="card-body text-center">
                            <ul class="list-group list-unstyled">
                                <li class="font-weight-bold">
                                    <?php if($car->company_id): ?>
                                        <?php echo e(\App\Company::findOrFail($car->company_id)->name); ?>

                                    <?php else: ?>
                                        None
                                    <?php endif; ?>
                                </li>
                                <li class="">Tax token <?php echo e($car->tax_token_expiry_date->diffForHumans()); ?></li>
                                <li class="">Fitness <?php echo e($car->fitness_expiry_date->diffForHumans()); ?></li>
                                <li class="">Insurance <?php echo e($car->insurance_expiry_date->diffForHumans()); ?></li>
                                <li class="">Road permit <?php echo e($car->road_permit_expiry_date->diffForHumans()); ?></li>
                            </ul>
                        </div>
                        <div class="card-footer bg-transparent border-success float-right">
                            <span class="float-right">
                                <a href="<?php echo e(route('car.report', $car->registration_num)); ?>" class="btn btn-sm btn-outline-success mr-2">
                                    <i class="fa fa-book"></i> Report
                                </a>
                                <a href="<?php echo e(route('car.edit', $car->registration_num)); ?>" class="card-link btn btn-sm btn-outline-success">
                                    <i class="fa fa-pencil"></i> Edit
                                </a>
                            </span>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h3>No Cars</h3>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>