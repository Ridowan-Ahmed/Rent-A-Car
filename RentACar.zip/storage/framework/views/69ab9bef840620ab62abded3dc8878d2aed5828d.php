<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/car">Car</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($car->registration_num); ?></li>
    </ol>
</nav>
<div class="container img-thumbanil">
    <div class="row">
        <div class="col">
            <?php if($company_contract && $owner_contract): ?>
            <table class="table table-striped table-hover">
                <caption>List car cost</caption>
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col"><?php echo e($company->name); ?></th>
                    <th scope="col"><?php echo e($owner->name); ?></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <th scope="row">Octane Cost</th>
                    <td><?php echo e($company_contract->octane_cost); ?></td>
                    <td><?php echo e($owner_contract->octane_cost); ?></td>
                </tr>
                <tr>
                    <th scope="row">Diesel Cost</th>
                    <td><?php echo e($company_contract->diesel_cost); ?></td>
                    <td><?php echo e($owner_contract->diesel_cost); ?></td>
                </tr>
                <tr>
                    <th scope="row">Cng Cost</th>
                    <td><?php echo e($company_contract->cng_cost); ?></td>
                    <td><?php echo e($owner_contract->cng_cost); ?></td>
                </tr>
                <tr>
                    <th scope="row">Parking Mode</th>
                    <td><?php echo e($company_contract->parking_mode); ?></td>
                    <td><?php echo e($owner_contract->parking_mode); ?></td>
                </tr>
                <tr>
                    <th scope="row">Car Rent</th>
                    <td><?php echo e($company_contract->car_rent); ?></td>
                    <td><?php echo e($owner_contract->car_rent); ?></td>
                </tr>
                <tr>
                    <th scope="row">Driver Salary</th>
                    <td><?php echo e($company_contract->driver_salary); ?></td>
                    <td><?php echo e($owner_contract->driver_salary); ?></td>
                </tr>
                <tr>
                    <th scope="row">Overtime Cost</th>
                    <td><?php echo e($company_contract->overtime_cost); ?></td>
                    <td><?php echo e($owner_contract->overtime_cost); ?></td>
                </tr>
                <tr>
                    <th scope="row">Breakfast Cost</th>
                    <td><?php echo e($company_contract->breakfast_cost); ?></td>
                    <td><?php echo e($owner_contract->breakfast_cost); ?></td>
                </tr>
                <tr>
                    <th scope="row">Launch Cost</th>
                    <td><?php echo e($company_contract->launch_cost); ?></td>
                    <td><?php echo e($owner_contract->launch_cost); ?></td>
                </tr>
                <tr>
                    <th scope="row">Dinner Cost</th>
                    <td><?php echo e($company_contract->dinner_cost); ?></td>
                    <td><?php echo e($owner_contract->dinner_cost); ?></td>
                </tr>
                <tr>
                    <th scope="row">Contract Type</th>
                    <td><?php echo e($company_contract->contract_type); ?></td>
                    <td><?php echo e($owner_contract->contract_type); ?></td>
                </tr>
                <tr>
                    <th scope="row">Contract Duration</th>
                    <td><?php echo e($company_contract->contract_duration); ?></td>
                    <td><?php echo e($owner_contract->contract_duration); ?></td>
                </tr>
                <tr>
                    <th scope="row">Remarks</th>
                    <td><?php echo e($company_contract->remarks); ?></td>
                    <td><?php echo e($owner_contract->remarks); ?></td>
                </tr>

                </tbody>
            </table>
            <?php else: ?>
            <p>No Contract added yet</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>