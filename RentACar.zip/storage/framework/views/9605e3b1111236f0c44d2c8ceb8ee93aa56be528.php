<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/owner">Owner</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('owner.show', $car->owner->slug)); ?>"><?php echo e($car->owner->name); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Daily Log</li>
                </ol>
            </nav>
        </ol>
    </nav>
    <div id="carLog" class="">
        <h1 class="display-5" id="logIndex">
            <i class="fa fa-taxi"></i> <?php echo e($car->registration_num); ?> <span class="badge badge-primary badge-pill"><?php echo e($car->car_brand); ?></span>
        </h1>
        <div id="logControl" class="text-center my-2">
            <a href="<?php echo e(route('logbook.showPastTwo', $car->registration_num)); ?>" class="btn btn-outline-primary">Past Two Month</a>
            <a href="<?php echo e(route('logbook.showPast', $car->registration_num)); ?>" class="btn btn-outline-success">Past Month</a>
            <a href="<?php echo e(route('logbook.show', $car->registration_num)); ?>" class="btn btn-outline-secondary">This Month</a>
        </div>
        <?php if(count($logbooks) > 0): ?>
        <table class="table table-danger table-responsive-sm table-bordered table-hover table-stripped">
            <thead class="">
            <tr>
                <th>Date</th>
                <th>Total Run</th>
                <th>Starting Time</th>
                <th>Ending Time</th>
                <th>Working</th>
                <th>Overtime</th>
                <th>Payment Reason</th>
                <th>Payment Type</th>
                <th>Amount</th>
            </tr>
            </thead>
            <tbody class="wow fadeInDownBig">
                <?php $__currentLoopData = $logbooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php
                            $date = new \Carbon\Carbon($logbook->log_date);
                            $start = new \Carbon\Carbon($logbook->starting_time);
                            $end = new \Carbon\Carbon($logbook->ending_time);
                            $working_time = $end->diffInHours($start);
                            $total_run = $logbook->octane_ending_km-$logbook->octane_starting_km;
                            $total_run += $logbook->diesel_ending_km-$logbook->diesel_starting_km;
                            $total_run += $logbook->cng_ending_km-$logbook->cng_starting_km;
                        ?>
                        <td><?php echo e($date->toFormattedDateString()); ?></td>
                        <td><?php echo e($total_run); ?> KM</td>
                        <td><?php echo e($start->format('h:i A')); ?></td>
                        <td><?php echo e($end->format('h:i A')); ?></td>
                        <td><?php echo e($working_time); ?> h</td>
                        <td>
                            <?php if($working_time === $car->driver_duty): ?>
                                <h5><span class="badge badge-primary badge-pill"><i class="fa fa-check-circle-o"></i> OK</span>
                                </h5>
                            <?php elseif($working_time > $car->driver_duty): ?>
                                <h5><span class="badge badge-danger badge-pill"><i
                                                class="fa fa-check-circle-o"></i> <?php echo e($working_time - $car->driver_duty); ?>

                                        h</span></h5>
                            <?php else: ?>
                                <?php echo e($car->driver_duty - $working_time); ?> h less
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($logbook->payment_reason); ?></td>
                        <td><?php echo e($logbook->payment_type); ?></td>
                        <td><?php echo e($logbook->payment_amount); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>No Entry yet</p>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>