<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/company">Company</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('company.show', $company->slug)); ?>"><?php echo e($company->name); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page">Full Report</li>
        </ol>
    </nav>
    <div id="ownerReport dark-overlay">
        <table class="table table-sm table-responsive-sm table-bordered table-hover table-stripped">
            <thead class="table-dark">
            <tr>
                <th>Car</th>
                <th>Total</th>
            </tr>
            </thead>
            <tbody>
            <?php
                $total_due = 0;
            ?>
            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="<?php echo e(route('car.report', $report->registration_num)); ?>"><?php echo e($report->registration_num); ?></a></td>
                    <?php
                        $car = App\Car::whereRegistrationNum($report->registration_num)->first();
                        $contract_company =  $car->company->contract->where('brand_id',$car->brand->id)->first();
                    ?>
                    <?php if($contract_company): ?>
                        <?php
                            $total = $report->octane_km*$contract_company->octane_cost;
                            $total += $report->diesel_km*$contract_company->diesel_cost;
                            $total += $report->cng_km*$contract_company->cng_cost;
                            $total += $contract_company->starting_octane*$contract_company->octane_cost;
                            $total += $report->overtime_hour*$contract_company->overtime_cost;
                            $total += $report->cnt*$contract_company->breakfast_cost;
                            $total += $report->cnt*$contract_company->launch_cost;
                            $total += $report->cnt*$contract_company->dinner_cost;
                            $total += $contract_company->car_rent;
                            $total_due += $total;
                        ?>
                        <td class="text-sm-left"><?php echo e($total); ?> &#x9f3;</td>
                    <?php else: ?>
                        <td colspan="3" class="bg-danger text-center">No Contract</td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr class="font-weight-bold">
                <td class="text-right">Total Due</td>
                <td class="bg-success"><?php echo e($total_due); ?> &#x9f3;</td>
            </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>